<div>
    <h4>Conversion Result</h4>
    <p>{{ session('result', 'No conversion yet.') }}</p>
</div>
